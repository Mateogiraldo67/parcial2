import React from 'react';
import ContactList from './Components/ObtenerDatos'; 

const App = () => {
  return (
    <div>
      <h1>Contactos</h1>
      <ContactList />
    </div>
  );
};

export default App;

