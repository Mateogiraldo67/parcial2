import React, { useState, useEffect } from 'react';
import axios from 'axios';
import "./Obtener.css"
const ContactList = () => {
  const [contacts, setContacts] = useState([]);
  const [selectedContact, setSelectedContact] = useState(null);
  const [newContact, setNewContact] = useState({ names: '', telephone: '', image: '' });

  useEffect(() => {
    
    axios.get('https://kpw1ch0aa1.execute-api.us-east-2.amazonaws.com/dev/project')
      .then(response => {
       
        setContacts(response.data);
      })
      .catch(error => {
        console.error('no se pudo obtener los contactos:', error);
      });
  }, []);

  const handleContactClick = (contact) => {
   
    setSelectedContact(contact);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewContact({ ...newContact, [name]: value });
  };

  const handleAddContact = () => {
  
    axios.post('https://kpw1ch0aa1.execute-api.us-east-2.amazonaws.com/dev/project', newContact)
      .then(response => {
      
        setContacts([...contacts, response.data]);
   
        setNewContact({ names: '', telephone: '', image: '' });
      })
      .catch(error => {
     
        console.error('Error al agregar contacto:', error);
      });
  };

  return (
    <div className="contact-list">
      <div className="contact-add">
        <h2>Agregar Contacto</h2>
        <input type="text" name="names" placeholder="Nombre" value={newContact.names} onChange={handleInputChange} />
        <input type="text" name="telephone" placeholder="Teléfono" value={newContact.telephone} onChange={handleInputChange} />
        <input type="text" name="image" placeholder="URL de la imagen" value={newContact.image} onChange={handleInputChange} />
        <button onClick={handleAddContact}>Agregar</button>
      </div>
      <div className="contact-list-container">
        <div className="contact-list-buttons">
          <h2>Contactos</h2>
          <div className="contact-button-container">
            {contacts.map(contact => (
              <div key={contact.identify} className="contact-div" onClick={() => handleContactClick(contact)}>
                {contact.names}
              </div>
            ))}
          </div>
        </div>
        <div className="contact-details">
          {selectedContact && (
            <>
              <h2>Detalles del contacto </h2>
              <p>Nombre: {selectedContact.names}</p>
              <p>Número de teléfono: {selectedContact.telephone}</p>
              <img src={selectedContact.image} alt={selectedContact.names} />
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ContactList;
