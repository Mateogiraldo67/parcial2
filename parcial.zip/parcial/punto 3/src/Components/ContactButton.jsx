import React from 'react';

const ContactButton = ({ contact, onClick }) => {
  return (
    <button className="contact-button" onClick={() => onClick(contact)}>
      {contact.names}
    </button>
  );
};

export default ContactButton;




